(Work in progress)

Banner — simple and actually working fail2ban analog

IPv6: yes

Reqs: *BSD (for now), modern C compiler, pcre.

